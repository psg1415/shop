package com.models.mypage;

public class MyPageDao {

}
